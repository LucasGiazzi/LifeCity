import 'package:flutter/material.dart';
import 'components/intro_page_body_area.dart';

class IntroLoginPage extends StatelessWidget {
  const IntroLoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: IntroPageBodyArea(),
    );
  }
}
