ALTER TABLE users ADD CONSTRAINT users_cpf_unique UNIQUE (cpf);
