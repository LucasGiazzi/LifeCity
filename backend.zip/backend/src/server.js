const app = require('./app');
const http = require('http');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const supabasePool = require('./infra/supabasePool');

dotenv.config();

const PORT = process.env.PORT || 3000;

async function runMigration(pool, name, sql) {
    try {
        await pool.query(sql);
        console.log(`[migration] OK: ${name}`);
    } catch (err) {
        console.error(`[migration] FAILED: ${name} — ${err.message}`);
    }
}

async function runMigrations() {
    const pool = await supabasePool.getPgPool();

    await runMigration(pool, 'complaints.status', `
        ALTER TABLE complaints
        ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'pending'
    `);

    await runMigration(pool, 'complaint_witnesses', `
        CREATE TABLE IF NOT EXISTS complaint_witnesses (
            id BIGSERIAL PRIMARY KEY,
            complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
            user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE(complaint_id, user_id)
        )
    `);
}

const server = http.createServer(app);

server.listen(PORT, async () => {
    console.log(`Server is running on port ${PORT}`);
    await runMigrations();
});

app.get('/', (req, res) => {
    res.send('Hello World');
});

